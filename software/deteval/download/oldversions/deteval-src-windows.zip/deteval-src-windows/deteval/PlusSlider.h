#ifndef HEADER_PLUSSLIDER
#define HEADER_PLUSSLIDER

#include <QtGui>

class PlusSlider : public QWidget
{
	Q_OBJECT

	public:
		PlusSlider(QWidget *parent,QString ToolTip, int Default, int Max=100);
		void setPageStep(int Step);
		int value();

	public slots:
		void connectSliderSpinBox(int V);
		void connectSpinBoxSlider(double V);
	signals:
		void valueChanged(int);

	private:
		QSlider *Slider;
		QDoubleSpinBox* Valeur;
};

#endif
