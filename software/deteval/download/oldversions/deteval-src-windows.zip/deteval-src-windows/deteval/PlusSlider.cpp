#include "PlusSlider.h"

PlusSlider::PlusSlider(QWidget *parent,QString ToolTip, int Default, int Max) : QWidget(parent)
{
	Slider = new QSlider(this);
	Slider->setMaximum(Max);
	Slider->setOrientation(Qt::Vertical);
	Slider->setToolTip(ToolTip);
	Slider->setValue(Default);


	QVBoxLayout* LayoutOut = new QVBoxLayout(this);
	QHBoxLayout* LayoutIn = new QHBoxLayout(LayoutOut->widget());

	LayoutIn->addWidget(Slider);
	LayoutOut->addLayout(LayoutIn);

	Valeur = new QDoubleSpinBox(this);
	Valeur->setMaximum(Max);
	Valeur->setSingleStep(1);
	Valeur->setDecimals(0);
	Valeur->setToolTip(ToolTip);
	LayoutOut->addWidget(Valeur);

	QObject::connect(Slider,SIGNAL(valueChanged(int)),this,SIGNAL(valueChanged(int)));
	QObject::connect(Slider,SIGNAL(valueChanged(int)),this,SLOT(connectSliderSpinBox(int)));
	QObject::connect(Valeur,SIGNAL(valueChanged(double)),this,SLOT(connectSpinBoxSlider(double)));

	connectSliderSpinBox(Default);//Effectuer la connexion pour la veleur par d�faut

}

void PlusSlider::setPageStep(int Step)
{
	Slider->setPageStep(Step);
}

int PlusSlider::value()
{
	return Slider->value();
}

void PlusSlider::connectSliderSpinBox(int V)
{
	Valeur->setValue(float(V));
}

void PlusSlider::connectSpinBoxSlider(double V)
{
	Slider->setValue(V);
}
