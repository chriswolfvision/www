#ifndef HEADER_MAIN
#define HEADER_MAIN

#include <QApplication>
#include <QtGui>
#include <QProcess>
#include "MainForm.h"
#include "RenderArea.h"

bool shell(QString cmd,QMainWindow* Caller);
QString loadFile(QString Path);
QString EscapeFile(QString File);

#endif
