#include "main.h"
#include <QtDebug>


/**
Conventions de nommage
- Variables : UpperCamelCase
	* Pour les variables normales : mot ou enchainement de mot
	* Pour les widgets : (mot ou enchainement de mot)Type =>QuitAction, QuitButton
- Fonctions : lowerCamelCase
- Classes : UpperCamelCase
*/

/**
(tous les documents sont encod�s en ISO 8859 1)
Comment �a marche ?
Les zones de graphiques sont des composants sp�ciaux programm�es pour l'occasion : RenderArea
Les sliders sont mis en corr�lation avec un QSpinBox (le champ de texte en dessous qui indique la valeur actuelle du slider) : il s'agit encore d'une classe sp�ciale, PlusSlider qui �met le m�me SIGNAL que le QSlider original.

L'interface est enit�rement d�finie dans le code (MainForm). Toutes les connexions SIGNAL / SLOT sont g�r�es au m�me endroit.
MainForm est un fichier volumineux, subdivis� en trois parties :
1 / Tout ce qui est "interface" : composants, affichage des boites de dialogue de s�lection de fichier...
2 / (aux environs de la ligne 400) Gestion des fichiers PDF et PNG
3 / (autout de 475) Partie "importante" : gestion de rocplot et d'evalplots.

Les fonctions "bas-niveau" sont dans le fichier main.cpp : ouverture d'un fichier, lancer une commande.

� savoir : La constante Q_WS_WIN vaut true si la compilation se fait sous Windows : elle est utilis�e � diff�rents endroits afin d'obtenir un ensemble de fichiers multi plateformes.

Les icones sont inclues directement dans l'ex�cutable � l'aide d'un fichier de ressources.

L'ensemble est compilable � l'aide du trio qmake -project, qmake et make ; il n'est pas n�cessaire d'apporter des modifications au fichier .pro g�n�r� automatiquement.
*/

int main(int argc, char *argv[])
{
	//Cr�er l'application
	QApplication app(argc, argv);

	//Charger les traductions fran�aises :
	QString locale = QLocale::system().name();
	QTranslator translator;
	translator.load(QString("qt_") + locale, QLibraryInfo::location(QLibraryInfo::TranslationsPath));
	app.installTranslator(&translator);

	//Afficher la fenetre principale.
	MainForm fenetre;
	fenetre.show();

	return app.exec();
}

/////////////////////////
//Lancer une commande
/////////////////////////
bool shell(QString cmd,QMainWindow* Caller)
{
	Caller->setCursor(Qt::WaitCursor);

    QProcess script;
    #ifdef Q_WS_WIN
		cmd = cmd.replace("/","\\");//Windows utilise des backslashes
		script.setWorkingDirectory(qApp->applicationDirPath());
	#else
		script.setWorkingDirectory("/tmp");
    #endif
	qDebug() << "Will run command line : " << cmd;

	script.start(cmd);
	if (!script.waitForFinished())
	{
		#ifdef Q_WS_WIN
		QMessageBox::critical(0, "Unable to get QProcess", QString("Error : %1.<br />Most probably, you forget to install Ruby.<br /> See readme for details.").arg(script.error()));
		#else
		QMessageBox::critical(0, "Unable to get QProcess", QString("Error : %1.<br />Most probably, evalpots and rocplot are unavailable (are you able to launch them in a standard shell with the command you provided ? See Settings->Change Path to update PATH infos). See readme for details.").arg(script.error()));
		#endif
	}
	Caller->unsetCursor();
	return !script.readAllStandardError().contains("ERROR");
}

/////////////////////////
//Ouvrir un fichier
/////////////////////////
QString loadFile(QString Path)
{
	#ifdef Q_WS_WIN
		Path = qApp->applicationDirPath() + "/" + Path;
	#else
		Path = "/tmp/" + Path;
	#endif
	QFile Doc(Path);
	QString texte;

	if(Doc.open(QIODevice::ReadOnly))
	{
		texte = Doc.readAll();
		Doc.close();
	}
	else
		QMessageBox::information(0, "Error !", "Unable to read file " + Path);

	return texte;
}

QString EscapeFile(QString File)
{
	if(File.indexOf(" ")!=-1)
		return "\"" + File + "\"";
	else
		return File;

}
