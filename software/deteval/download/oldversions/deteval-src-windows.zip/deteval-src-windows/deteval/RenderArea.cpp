#include "RenderArea.h"

RenderArea::RenderArea(QWidget *parent,QString mAbscisse, QString mOrdonnee) : QLabel(parent)
{
	setBackgroundRole(QPalette::Base);
	setAutoFillBackground(true);
	this->setPixmap(QPixmap("icones/Fond.png"));
	title="";
	Abscisse=mAbscisse;
	Ordonnee=mOrdonnee;

	clear();
}

//Charger des nouvelles id�es
void RenderArea::addDataSet(QList<float> XDatas,QList<float> YDatas,Qt::GlobalColor Couleur)
{
	Points.clear();

	//Note importante : il faut effecteur un changement de coordonn�es pour les Y puisque le rep�re informatique a son origine en HAUT � gauche.
	for (int i = 0; i < XDatas.size(); i++)
		Points << QPointF(XDatas.at(i),1 - YDatas.at(i));

	Datas << Points;
	Couleurs << Couleur;
	update();
}

void RenderArea::clear()
{
	Datas.clear();
	Couleurs.clear();
}

void RenderArea::setTitle(QString newTitle)
{
	title=newTitle;
	update();
}

//Repeindre le graphique
void RenderArea::paintEvent(QPaintEvent * /* event */)
{
	draw(this,1);
}

void RenderArea::draw(QPaintDevice* Device,int Width)
{
	QPainter painter(Device);
	int i;
	int j;

	int W=Device->width();
	int H=Device->height();
	float LineWidth = float(Width)/W;

	//Charger le fond (une image avec les unit�s)
	painter.drawImage(QRect(0,0,W,H),QImage(":/I/icones/Fond.png"),QRectF(0,0,572,428));

	//Afficher le titre demand�
	//D�sactiv� � la demande de anh phuong
// 	painter.setPen(QPen(Qt::green));
// 	painter.setFont(QFont("Arial", 12));
// 	painter.drawText(20,20, title);

	//Afficher abscisse et ordonn�e
	painter.setPen(Qt::black);
	painter.setFont(QFont("Arial", 7));
	painter.drawText(W/2,H-12,Abscisse);
	for(int i=2;i<=8;i +=2)
		painter.drawText((W*i)/10 - 5,H-6,QString::number(float(i)/10));
	painter.rotate(90);
	painter.drawText(H/2,-12,Ordonnee);
	for(int i=2;i<=8;i +=2)
		painter.drawText((H*i)/10 - 5,-6,QString::number(1-float(i)/10));
	painter.rotate(-90);

	//NE RIEN FAIRE SI AUCUNE DONN�E
	if(Datas.count()==0)
		return;


	//Et afficher les donn�es
	painter.scale(W,H);
	painter.setRenderHint(QPainter::Antialiasing);

	QPainterPath *path;
	for(j=0;j<Datas.size();j++)
	{
		Points=Datas.at(j);

		painter.setPen(QPen(Couleurs.at(j),LineWidth));

		path = new QPainterPath(Points.at(0));


		for (i = 0; i < Points.size(); i++)
		{
			path->lineTo(Points.at(i));
			if(Width==1)
			{
				path->addEllipse(Points.at(i).x(),Points.at(i).y(),0.005,0.005);
				path->moveTo(Points.at(i));
			}
		}

		painter.drawPath(*path);
		delete path;
	}

	painter.end();
}
