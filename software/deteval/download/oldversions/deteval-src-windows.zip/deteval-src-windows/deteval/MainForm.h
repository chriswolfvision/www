#ifndef HEADER_FENPRINCIPALE
#define HEADER_FENPRINCIPALE

#include "RenderArea.h"
#include "main.h"
#include "PlusSlider.h"
#include <QtGui>

class MainForm : public QMainWindow
{
	Q_OBJECT

	public:
		MainForm();

		QAction *AddGTAction;
		QAction *AddXMLAction;
		QAction *CleanAction;
		QAction *QuitAction;
		QAction *ChangePathAction;
		QAction *Advanced_FeaturesAction;
		QAction *RocplotPNGAction;
		QAction *RocplotPDFAction;
		QAction *EvalplotTpPNGAction;
		QAction *EvalplotTrPNGAction;
		QAction *EvalplotTpPDFAction;
		QAction *EvalplotTrPDFAction;
		QWidget *centralwidget;
		QHBoxLayout *horizontalLayout;
		QVBoxLayout *XmlLayout;
		QLineEdit *GTEdit;
		QPushButton *AddGTButton;

		QTabWidget* XML_SetsTab;
		int NumberOfInsertedTabs;
		QList<QListWidget*> XML_SetsEdit;

		QListWidget* XMLEdit;

		QLabel *helpEvalplots;
		QPushButton *AddXMLButton;
		QPushButton *CleanButton;
		QVBoxLayout *GraphLayout;
		QHBoxLayout *RocplotLayout;
		RenderArea *Rocplot;
		RenderArea *EvalplotTr;
		RenderArea *EvalplotTp;
		PlusSlider *RecallSlider;
		PlusSlider *PrecisionSlider;
		PlusSlider *BorderVerificationSlider;
		PlusSlider *CenterRectangleSlider;
		QHBoxLayout *RocplotSettingsLayout;
		QLineEdit *RocplotOption;
		QLabel *RocplotObjetsLabel;
		QLabel *RocplotOptionLabel;
		QLineEdit *RocplotObjets;
		QMenuBar *Menus;
		QMenu *MenuFile;
		QMenu *MenuSave;
		QMenu *MenuSettings;

		QList < QWidget* > AdvancedWidgets;//Liste de widgets avanc�s qui sont masqu�s par d�faut.

		QSettings *Settings;

	public slots:
		void addGT();//Ajouter un fichier GrounTruth
		void addXML();//Ajouter un fichier XML
		void addNewXMLToTab();//Permet d'ajouter un fichier XML � un onglet d�j� existant.
		void setMode();//Passer du mode normal au mode avanc� et vice versa.
		void updateRocplot();//Mettre � jour l'image Rocplot
		void updateEvalplots(QListWidgetItem* ItemSelectionne);//Mettre � jour le graphe d'evaloplot
		void close();//Fermer cette fen�tre, mais aussi les evaloplot
		void removeTab();//Supprimer un onglet de fichier XML
		void cleanAll();//Supprimer tous les onglets
		void saveRocplotPNG();
		void saveRocplotPDF();
		void saveEvalplotTrPNG();
		void saveEvalplotTpPNG();
		void saveEvalplotTrPDF();
		void saveEvalplotTpPDF();
		void createSettings();//Modifier les lignes de commande.

	signals:
		void changeXML();//�venement d�clench� lors de la modification des fichiers XML.


	private:
		void getDatas(QString File,QList<float> *Abs,QList<float> *Ord);
		void addSetsTab(QStringList Files);
		void savePNG(RenderArea *Source, QString Title);
		void savePDF(RenderArea *Source, QString Title);
		void addXMLsToTab(QStringList Files, QListWidget* Liste);
};


#endif
