#include "MainForm.h"

MainForm::MainForm(): QMainWindow()
{
	//Fen�tre principale

	this->setWindowTitle("MainWindow");
	this->resize(640, 480);
	NumberOfInsertedTabs=0;

	Settings = new QSettings("liris", "deteval");

	//� la premi�re utilisation, enregistrer les options.
	if(Settings->value("rocplot","NC")=="NC")
	{
		#ifdef Q_WS_WIN
		Settings->setValue("rocplot","ruby rocplot.rb");
		Settings->setValue("evalplots","ruby evalplots.rb");
		#else
		Settings->setValue("rocplot","rocplot");
		Settings->setValue("evalplots","evalplots");
		#endif
	}

	//Le layout global
		centralwidget = new QWidget(this);

		horizontalLayout = new QHBoxLayout(centralwidget);

		horizontalLayout->setSizeConstraint(QLayout::SetDefaultConstraint);

	//Le layout XML
		XmlLayout = new QVBoxLayout();
		XmlLayout->setSizeConstraint(QLayout::SetMinimumSize);

		GTEdit = new QLineEdit(centralwidget);
		GTEdit->setMaximumSize(QSize(250, 16777215));
		GTEdit->setReadOnly(true);

		AddGTButton = new QPushButton(centralwidget);
		AddGTButton->setMaximumSize(QSize(250, 16777215));
		AddGTButton->setText("Set groundtruth.xml");
		AddGTButton->setIcon(QIcon(":/icones/GT.png"));

		XML_SetsTab = new QTabWidget(centralwidget);
		XML_SetsTab->setMaximumSize(QSize(250, 16777215));


		helpEvalplots = new QLabel(centralwidget);
		helpEvalplots->setText("<strong>Select</strong> a file to<br />display quality curves.");
		helpEvalplots->setAlignment(Qt::AlignHCenter);
		helpEvalplots->setMaximumSize(QSize(250, 16777215));

		AddXMLButton = new QPushButton(centralwidget);
		AddXMLButton->setMaximumSize(QSize(250, 16777215));
		AddXMLButton->setText("Add new set\nof xml files");
		AddXMLButton->setIcon(QIcon(":/icones/XMLs.png"));

		CleanButton = new QPushButton(centralwidget);

		CleanButton->setMaximumSize(QSize(250, 16777215));
		CleanButton->setText("Clean all");
		CleanButton->setIcon(QIcon(":/icones/Clean.png"));

		//Ajouter dans le layout
		XmlLayout->addWidget(GTEdit);
		XmlLayout->addWidget(AddGTButton);
		XmlLayout->addWidget(XML_SetsTab);
		XmlLayout->addWidget(helpEvalplots);
		XmlLayout->addWidget(AddXMLButton);
		XmlLayout->addWidget(CleanButton);

	horizontalLayout->addLayout(XmlLayout);

	//Le layout des graphiques
		GraphLayout = new QVBoxLayout();

		GraphLayout->setSizeConstraint(QLayout::SetMaximumSize);

		//Le layout pour RocPlot
			RocplotLayout = new QHBoxLayout();


			Rocplot = new RenderArea(centralwidget,"Recall","Precision");

			//Faire en sorte que le graphique s'�tende au maximum
			QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
			sizePolicy.setHorizontalStretch(0);
			sizePolicy.setVerticalStretch(0);
			sizePolicy.setHeightForWidth(Rocplot->sizePolicy().hasHeightForWidth());
			Rocplot->setSizePolicy(sizePolicy);
			Rocplot->setMinimumSize(QSize(429,321));
			RocplotLayout->addWidget(Rocplot);

 			RecallSlider = new PlusSlider(centralwidget,"Recall",80);
			RocplotLayout->addWidget(RecallSlider);
			PrecisionSlider = new PlusSlider(centralwidget,"Precision",40);
			RocplotLayout->addWidget(PrecisionSlider);
			BorderVerificationSlider = new PlusSlider(centralwidget,"Do border verification",0,1);
			BorderVerificationSlider->setPageStep(1);
			RocplotLayout->addWidget(BorderVerificationSlider);
			CenterRectangleSlider = new PlusSlider(centralwidget,"Difference of the centers of two matching rectangles",100);
			RocplotLayout->addWidget(CenterRectangleSlider);

			this->setWindowTitle("DetEval");



		GraphLayout->addLayout(RocplotLayout);

		//Le layout pour Evalplots
			RocplotSettingsLayout = new QHBoxLayout();



			RocplotObjetsLabel = new QLabel(centralwidget);
			RocplotObjetsLabel->setText("Restrict object types to :<br /><small>(comma separated list)</small>");

			RocplotObjets = new QLineEdit(centralwidget);

			RocplotOptionLabel = new QLabel(centralwidget);
			RocplotOptionLabel->setText("Add arguments<br />to command line : ");
			RocplotOption = new QLineEdit(centralwidget);

			RocplotSettingsLayout->addWidget(RocplotObjetsLabel);
			RocplotSettingsLayout->addWidget(RocplotObjets);
			RocplotSettingsLayout->addWidget(RocplotOptionLabel);
			RocplotSettingsLayout->addWidget(RocplotOption);

		GraphLayout->addLayout(RocplotSettingsLayout);

	horizontalLayout->addLayout(GraphLayout);

	EvalplotTr= new RenderArea(0,"x = tr","");
	EvalplotTr->window()->setWindowTitle("EvalplotTr");
	EvalplotTr->setTitle("Evalplot Recall");
	EvalplotTr->resize(286,214);

	EvalplotTp= new RenderArea(0,"x = tp","");
	EvalplotTp->window()->setWindowTitle("EvalplotTp");
	EvalplotTp->setTitle("Evalplot - Precision");
	EvalplotTp->resize(286,214);

	this->setCentralWidget(centralwidget);
	QWidget::setTabOrder(AddGTButton, AddXMLButton);
	QWidget::setTabOrder(AddXMLButton, RecallSlider);
	QWidget::setTabOrder(RecallSlider, PrecisionSlider);
	QWidget::setTabOrder(PrecisionSlider, CleanButton);
	QWidget::setTabOrder(CleanButton, GTEdit);


	Menus = new QMenuBar(this);
	Menus->setGeometry(QRect(0, 0, 607, 28));
	MenuFile = new QMenu(Menus);
	MenuSave = new QMenu(Menus);
	MenuSettings = new QMenu(Menus);
	this->setMenuBar(Menus);


	//Les menus et actions
	//File
		AddGTAction = new QAction(this);
		AddGTAction->setText("Set groundtruth.xml");
		AddGTAction->setIcon(QIcon(":/icones/GT.png"));
		AddXMLAction = new QAction(this);
		AddXMLAction->setText("Add xml file(s)");
		AddXMLAction->setIcon(QIcon(":/icones/XMLs.png"));
		CleanAction = new QAction(this);
		CleanAction->setText("Clear all");
		CleanAction->setIcon(QIcon(":/icones/Clean.png"));
		QuitAction = new QAction(this);
		QuitAction->setText("Quit");
		QuitAction->setIcon(QIcon(":/icones/Quit.png"));
		QuitAction->setShortcut(QApplication::translate("MainWindow", "Ctrl+Q", 0));

		Menus->addAction(MenuFile->menuAction());
		MenuFile->addAction(AddGTAction);
		MenuFile->addAction(AddXMLAction);
		MenuFile->addAction(CleanAction);
		MenuFile->addAction(QuitAction);
		MenuFile->setTitle("File");

	//Save in PDF / PNG
		RocplotPNGAction = new QAction(this);
		RocplotPNGAction->setText("Save rocplot in png");
		RocplotPNGAction->setIcon(QIcon(":/icones/PNG.png"));
		RocplotPDFAction = new QAction(this);
		RocplotPDFAction->setText("Save rocplot in pdf");
		RocplotPDFAction->setIcon(QIcon(":/icones/PDF.png"));
		EvalplotTrPNGAction = new QAction(this);
		EvalplotTrPNGAction->setText("Save evalplots recall in png");
		EvalplotTrPNGAction->setIcon(QIcon(":/icones/PNG.png"));
		EvalplotTrPDFAction = new QAction(this);
		EvalplotTrPDFAction->setText("Save evalplots recall in pdf");
		EvalplotTrPDFAction->setIcon(QIcon(":/icones/PDF.png"));
		EvalplotTpPNGAction = new QAction(this);
		EvalplotTpPNGAction->setText("Save evalplots precision in png");
		EvalplotTpPNGAction->setIcon(QIcon(":/icones/PNG.png"));
		EvalplotTpPDFAction = new QAction(this);
		EvalplotTpPDFAction->setText("Save evalplots precision in pdf");
		EvalplotTpPDFAction->setIcon(QIcon(":/icones/PDF.png"));

		Menus->addAction(MenuSave->menuAction());
		MenuSave->addAction(RocplotPNGAction);
		MenuSave->addAction(RocplotPDFAction);
		MenuSave->addAction(EvalplotTpPNGAction);
		MenuSave->addAction(EvalplotTpPDFAction);
		MenuSave->addAction(EvalplotTrPNGAction);
		MenuSave->addAction(EvalplotTrPDFAction);
		MenuSave->setTitle("Save");


	//Settings
		Advanced_FeaturesAction = new QAction(this);
		Advanced_FeaturesAction->setText("Advanced Features");
		Advanced_FeaturesAction->setCheckable(true);
		ChangePathAction = new QAction(this);
		ChangePathAction->setText("Change paths");

		Menus->addAction(MenuSettings->menuAction());
		MenuSettings->addAction(ChangePathAction);
		MenuSettings->addAction(Advanced_FeaturesAction);
		MenuSettings->setTitle("Settings");

	//Liste des widgets avanc�s :
	AdvancedWidgets << CenterRectangleSlider << BorderVerificationSlider << RocplotOption << RocplotOptionLabel;

	//Connexion et signaux
	QObject::connect(QuitAction,SIGNAL(triggered()),this,SLOT(close()));
	QObject::connect(CleanAction,SIGNAL(triggered()),CleanButton,SIGNAL(clicked()));
	QObject::connect(AddGTAction,SIGNAL(triggered()),AddGTButton,SIGNAL(clicked()));
	QObject::connect(AddXMLAction,SIGNAL(triggered()),AddXMLButton,SIGNAL(clicked()));
	QObject::connect(ChangePathAction,SIGNAL(triggered()),this,SLOT(createSettings()));
	QObject::connect(Advanced_FeaturesAction,SIGNAL(triggered()),this,SLOT(setMode()));
	QObject::connect(RocplotPNGAction,SIGNAL(triggered()),this,SLOT(saveRocplotPNG()));
	QObject::connect(RocplotPDFAction,SIGNAL(triggered()),this,SLOT(saveRocplotPDF()));
	QObject::connect(EvalplotTpPNGAction,SIGNAL(triggered()),this,SLOT(saveEvalplotTpPNG()));
	QObject::connect(EvalplotTpPDFAction,SIGNAL(triggered()),this,SLOT(saveEvalplotTpPDF()));
	QObject::connect(EvalplotTrPNGAction,SIGNAL(triggered()),this,SLOT(saveEvalplotTrPNG()));
	QObject::connect(EvalplotTrPDFAction,SIGNAL(triggered()),this,SLOT(saveEvalplotTrPDF()));

	QObject::connect(CleanButton, SIGNAL(clicked()), this,SLOT(cleanAll()));
	QObject::connect(AddGTButton,SIGNAL(clicked()),this,SLOT(addGT()));
	QObject::connect(AddXMLButton,SIGNAL(clicked()),this,SLOT(addXML()));

	//tous les �venements qui triggerent un updateRocplot :
	//changement des fichiers XML, updateEvalplotss des sliders, updateEvalplots des options
	QObject::connect(RecallSlider,SIGNAL(valueChanged(int)),this,SLOT(updateRocplot()));
	QObject::connect(PrecisionSlider,SIGNAL(valueChanged(int)),this,SLOT(updateRocplot()));
	QObject::connect(CenterRectangleSlider,SIGNAL(valueChanged(int)),this,SLOT(updateRocplot()));
	QObject::connect(BorderVerificationSlider,SIGNAL(valueChanged(int)),this,SLOT(updateRocplot()));
	QObject::connect(this,SIGNAL(changeXML()),this,SLOT(updateRocplot()));
	QObject::connect(RocplotOption,SIGNAL(editingFinished()),this,SLOT(updateRocplot()));
	QObject::connect(RocplotObjets,SIGNAL(editingFinished()),this,SLOT(updateRocplot()));
	QObject::connect(RocplotObjets,SIGNAL(editingFinished()),EvalplotTp,SLOT(hide()));
	QObject::connect(RocplotObjets,SIGNAL(editingFinished()),EvalplotTr,SLOT(hide()));
	QObject::connect(CleanButton,SIGNAL(clicked()),this,SLOT(updateRocplot()));

	//Masquer les fene�tres si changement
	QObject::connect(CleanButton,SIGNAL(clicked()),EvalplotTp,SLOT(hide()));
	QObject::connect(CleanButton,SIGNAL(clicked()),EvalplotTr,SLOT(hide()));
	QObject::connect(AddXMLButton,SIGNAL(clicked()),EvalplotTp,SLOT(hide()));
	QObject::connect(AddXMLButton,SIGNAL(clicked()),EvalplotTr,SLOT(hide()));
	QObject::connect(AddGTButton,SIGNAL(clicked()),EvalplotTp,SLOT(hide()));
	QObject::connect(AddGTButton,SIGNAL(clicked()),EvalplotTr,SLOT(hide()));

 	//GTEdit->setText("C:/Temp/xml_sample/_gt.xml");
	emit changeXML();
	setMode();//Masquer les widgets avanc�s.
}

void MainForm::addGT()
{
	QString GTFile = QFileDialog::getOpenFileName(this, "Groundtruth file", "", "Xml file (*.xml)");
	GTEdit->setText(GTFile);

	emit changeXML();
}

void MainForm::addXML()
{
	QStringList XMLFiles = QFileDialog::getOpenFileNames(this, "Results files", GTEdit->text(), "Xml file (*.xml)");

	addSetsTab(XMLFiles);

	emit changeXML();
}

//Ajout d'un onglet de sets.
void MainForm::addSetsTab(QStringList Files)//NE pas passser par r�f�rence car la doc recommande d'effectuer une copie...
{
	if(Files.count()<2)
		QMessageBox::information(this,"Uh oh...","You should select at least two files to run rocplot. Use <em>ctrl</em> and <em>shift</em> for multiple files selection.<br />The file has been added to your list, click on it to run evalplots. Rocplot will not use this file.");

	NumberOfInsertedTabs++;

	QWidget* XML_SetContainer;
	QVBoxLayout* XML_SetLayout;
	QListWidget* XML_SetEdit;
	QPushButton* XML_AddFile;
	QPushButton* XML_SetRemove;

	XML_SetContainer = new QWidget();

	XML_SetLayout = new QVBoxLayout(XML_SetContainer);

	XML_SetEdit = new QListWidget(XML_SetContainer);
	QPalette palette;
	QBrush brush(Qt::GlobalColor(9+NumberOfInsertedTabs));
	brush.setStyle(Qt::SolidPattern);
	palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush);
	palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush);
	XML_SetEdit->setPalette(palette);
	XML_SetEdit->setAlternatingRowColors(true);

	addXMLsToTab(Files,XML_SetEdit);

	//updateEvalplots
	QObject::connect(XML_SetEdit, SIGNAL(itemClicked(QListWidgetItem*)),this, SLOT(updateEvalplots(QListWidgetItem*)));
	QObject::connect(XML_SetEdit, SIGNAL(itemActivated(QListWidgetItem*)),this, SLOT(updateEvalplots(QListWidgetItem*)));

	XML_AddFile = new QPushButton(XML_SetContainer);
	XML_AddFile->setText("Add file(s) to this set");
	QObject::connect(XML_AddFile,SIGNAL(clicked()),this,SLOT(addNewXMLToTab()));

	XML_SetRemove = new QPushButton(XML_SetContainer);
	XML_SetRemove->setText("Remove this set of files");
	XML_SetRemove->setIcon(QIcon(":/icones/Clean.png"));
	QObject::connect(XML_SetRemove,SIGNAL(clicked()),this,SLOT(removeTab()));

	XML_SetLayout->addWidget(XML_SetEdit);
	XML_SetLayout->addWidget(XML_AddFile);
	XML_SetLayout->addWidget(XML_SetRemove);

	XML_SetsEdit << XML_SetEdit;//La liste des Listes
	XML_SetsTab->setCurrentIndex(XML_SetsTab->addTab(XML_SetContainer,QString::number(NumberOfInsertedTabs)));
}

void MainForm::addNewXMLToTab()
{
	QStringList NouveauxFichiers=QFileDialog::getOpenFileNames(this, "Results files", GTEdit->text(), "Xml file (*.xml)");
	QListWidget* CurrentListe=XML_SetsEdit.at(XML_SetsTab->currentIndex());
	addXMLsToTab(NouveauxFichiers,CurrentListe);

	updateRocplot();
}

void MainForm::addXMLsToTab(QStringList Files, QListWidget* Liste)//NE pas passser par r�f�rence car la doc recommande d'effectuer une copie...
{
	Files.sort();
	QStringList::Iterator it = Files.begin();
	while(it != Files.end())
	{
		Liste->addItem(*it);
		++it;
	}
}
void MainForm::removeTab()
{
	XML_SetsEdit.removeAt(XML_SetsTab->currentIndex());
	XML_SetsTab->removeTab(XML_SetsTab->currentIndex());

	emit changeXML();
}

void MainForm::cleanAll()
{
	GTEdit->clear();
	while(XML_SetsEdit.count()!=0)
		removeTab();
}

void MainForm::setMode()//Passer du mode normal au mode avanc� et vice versa.
{
	foreach( QWidget*w, AdvancedWidgets )
		w->setVisible(Advanced_FeaturesAction->isChecked());
}

void MainForm::createSettings()
{
	Settings->setValue("rocplot",QInputDialog::getText(this, "Rocplot path", "Which command should be used to run <strong>rocplot</strong> ?<br /><small>(if you don't know, see ReadMe.htm)</small>",QLineEdit::Normal,Settings->value("rocplot","rocplot").toString()));
	Settings->setValue("evalplots",QInputDialog::getText(this, "Evalplots path", "Which command should be used to run <strong>evalplots</strong> ?<br /><small>(if you don't know, see ReadMe.htm)</small>",QLineEdit::Normal,Settings->value("evalplots","evalplots").toString()));
	QMessageBox::information(this,"Information","Informations saved.<br />To change again, you may go to <em>Settings->Change path</em>.");
}

















///_______________________________________________________________________________________________________________________________________________

/////////////////////////
//Enregistrement des diff�rents RenderArea dans un fichier PDF / PNG
/////////////////////////
void MainForm::savePNG(RenderArea *Source,QString Title)
{
	QString fichier = QFileDialog::getSaveFileName(this, Title, "", "PNG Files (*.png)");
	QImage* PNG = new QImage(500,500,QImage::Format_RGB32);
	PNG->fill(0xFFFFFF);
	Source->draw(PNG);

	if(!PNG->save(fichier,"png"))
		QMessageBox::critical(this,"Error","Unable to write PNG file.");

	delete PNG;
}

void MainForm::savePDF(RenderArea *Source,QString Title)
{
	QString fichier = QFileDialog::getSaveFileName(this, Title, "", "PDF Files (*.pdf)");
	QPrinter* PDF = new QPrinter();
	PDF->setOutputFileName(fichier);
	PDF->setOutputFormat(QPrinter::PdfFormat);
	Source->draw(PDF);

// 	if(!PNG->save(fichier,"png"))
// 		QMessageBox::critical(this,"Error","Unable to write PNG file.");

	delete PDF;
}

void MainForm::saveRocplotPNG()
{
	savePNG(Rocplot,"Save current Rocplot");
}
void MainForm::saveRocplotPDF()
{
	savePDF(Rocplot,"Save current Rocplot");
}
void MainForm::saveEvalplotTrPNG()
{
	if(EvalplotTr->isVisible())
		savePNG(EvalplotTr,"Save current recall evalplots");
	else
		QMessageBox::information(this,"Uh oh...","Select a file before saving !");
}
void MainForm::saveEvalplotTpPNG()
{
	if(EvalplotTp->isVisible())
		savePNG(EvalplotTp,"Save current precision evalplots");
	else
		QMessageBox::information(this,"Uh oh...","Select a file before saving !");
}
void MainForm::saveEvalplotTrPDF()
{
	if(EvalplotTr->isVisible())
		savePDF(EvalplotTr,"Save current recall evalplots");
	else
		QMessageBox::information(this,"Uh oh...","Select a file before saving !");
}
void MainForm::saveEvalplotTpPDF()
{
	if(EvalplotTp->isVisible())
		savePDF(EvalplotTp,"Save current precision evalplots");
	else
		QMessageBox::information(this,"Uh oh...","Select a file before saving !");
}












///_______________________________________________________________________________________________________________________________________________

/////////////////////////
//Appel� sur la modification des fichiers XML ou des sliders.s
/////////////////////////
void MainForm::updateRocplot()
{
	//Gestion des erreurs
	if(XML_SetsEdit.count()==0 || GTEdit->text()=="")
	{
		Rocplot->clear();
		Rocplot->setTitle("Select groundtruth and samples files !");
		Rocplot->update();
		return;
	}
	QRegExp Masque("[^0-9 ,]");
	if(RocplotObjets->text()!="" && Masque.indexIn(RocplotObjets->text())!=-1)
	{
		QMessageBox::information(this,"Error","Objects list must be comma separated, e.g. <strong>2,1</strong>.<br />Command will be run without this parameter.");
		RocplotObjets->setText("");
	}

	//Pr�paration de la commande
	QString PrecisionDemande = QString::number(float(PrecisionSlider->value()) / 100).replace(",",".");//S'assurer que le s�parateur d�cimal est un point et pas une virgule.
	QString RecallDemande = QString::number(float(RecallSlider->value())/100).replace(",",".");
	QString CenterDemande = QString::number(float(CenterRectangleSlider->value())/100).replace(",",".");


	Rocplot->setTitle("Rocplot | P : " + PrecisionDemande + "�| " + "R : " + RecallDemande);
	Rocplot->clear();


	for (int j = 0; j < XML_SetsEdit.size(); j++)
	{
		if(XML_SetsEdit.at(j)->count()>=2)
		{
			//Construction de la commande
			QString cmd=Settings->value("rocplot","rocplot").toString();
			//Les object-types
			if(RocplotObjets->text()!="")
					cmd +=" --object-types=" + RocplotObjets->text() + " ";
			//Les options demand�es
			cmd += " " + RocplotOption->text() + " ";
			//Precision et recall
			cmd +="--quality=" + RecallDemande + "," + PrecisionDemande + "," + RecallDemande + "," + PrecisionDemande + "," + PrecisionDemande + "," + RecallDemande + "," + QString::number(BorderVerificationSlider->value()) + "," + CenterDemande + " ";

			//Groundtruth
			cmd +=EscapeFile(GTEdit->text()) + " ";

			//XML samples
			for(int i=0;i<XML_SetsEdit.at(j)->count();i++)
				cmd +=EscapeFile(XML_SetsEdit.at(j)->item(i)->text()) + " ";

			if(!shell(cmd,this))
			{
						GTEdit->setText(cmd);
				QMessageBox::information(this,"Error","An error occurred while running rocplot tool with command line <em>" + cmd + "</em>.<br />Check if you're using wrong options, or if your xml files are valid rocplots file. With Windows, you should not use directory with spaces.");
				return;
			}

			//R�cup�rer les fichiers.
			QStringList PrecisionS = loadFile("roc-curve/Precision").remove(QRegExp("[0-9]+ ")).split("\n",QString::SkipEmptyParts);
			QStringList RecallS = loadFile("roc-curve/Recall").remove(QRegExp("[0-9]+ ")).split("\n",QString::SkipEmptyParts);

			QList<float> Precision,Recall;
			for (int i = 0; i < PrecisionS.size(); ++i)
			{
				Recall << RecallS.at(i).toFloat();
				Precision << PrecisionS.at(i).toFloat();
			}

			//Ajouter les donn�es dans Rocplot.
			Rocplot->addDataSet(Recall,Precision,Qt::GlobalColor(9+XML_SetsTab->tabText(j).toInt()));
		}
	}

	//Dessiner la diagonale
	QList<float> DiagX, DiagY;
	DiagX << 0 << 1;
	DiagY << 0 << 1;
	Rocplot->addDataSet(DiagX,DiagY,Qt::yellow);
}



/////////////////////////
//Appel� sur la s�lection d'un fichier XML
/////////////////////////

void MainForm::updateEvalplots(QListWidgetItem* ItemSelectionne)
{
	if(XML_SetsEdit.count()==0 || GTEdit->text()=="")
	{
		QMessageBox::information(this,"Error","No groudtruth file / no XML files selected...");
		return;
	}

	//Lancer la commande
	QString cmd=Settings->value("evalplots","evalplots").toString();
	//Les object-types
	if(RocplotObjets->text()!="")
		cmd +=" --object-types=" + RocplotObjets->text() + " ";
	cmd += " " + EscapeFile(ItemSelectionne->text()) + " " + EscapeFile(GTEdit->text());
	cmd += " " + EscapeFile(ItemSelectionne->text()) + " " + EscapeFile(GTEdit->text());

	shell(cmd,this);

	QList<float> Abscisse;
	QList<float> Harmonic;
	QList<float> Precision;
	QList<float> Recall;

	//TR :
	EvalplotTr->show();
	EvalplotTr->setTitle(ItemSelectionne->text().mid(ItemSelectionne->text().lastIndexOf('/')+1));
	EvalplotTr->clear();

	EvalplotTp->show();
	EvalplotTp->setTitle(ItemSelectionne->text().mid(ItemSelectionne->text().lastIndexOf('/')+1));
	EvalplotTp->clear();

	getDatas("evalcurve-tr/Harmonic mean",&Abscisse,&Harmonic);
	EvalplotTr->addDataSet(Abscisse,Harmonic,Qt::yellow);

	getDatas("evalcurve-tr/Precision",&Abscisse,&Precision);
	EvalplotTr->addDataSet(Abscisse,Precision,Qt::blue);

	getDatas("evalcurve-tr/Recall",&Abscisse,&Recall);
	EvalplotTr->addDataSet(Abscisse,Recall,Qt::red);

	getDatas("evalcurve-tp/Harmonic mean",&Abscisse,&Harmonic);
	EvalplotTp->addDataSet(Abscisse,Harmonic,Qt::yellow);

	getDatas("evalcurve-tp/Precision",&Abscisse,&Precision);
	EvalplotTp->addDataSet(Abscisse,Precision,Qt::blue);

	getDatas("evalcurve-tp/Recall",&Abscisse,&Recall);
	EvalplotTp->addDataSet(Abscisse,Recall,Qt::red);

}

//Utilis� uniquement par Evalplots, lit un fichier et le renvoie dans deux QList.
void MainForm::getDatas(QString File,QList<float> *Abs,QList<float> *Ord)
{
	Abs->clear();
	Ord->clear();
	QStringList Fichier = loadFile(File).split(QRegExp("\n| "));
	for(int i=0;i<Fichier.size()-1;i +=2)
	{
		*Abs << Fichier.at(i).toFloat();
		*Ord << Fichier.at(i+1).toFloat();
	}
}

//Fermer la fen�tre, mais aussi les fen�tres enfants.
void MainForm::close()
{
	qApp->closeAllWindows();
}
