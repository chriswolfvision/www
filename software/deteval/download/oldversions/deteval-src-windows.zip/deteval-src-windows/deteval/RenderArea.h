#ifndef HEADER_RENDER_AREA
#define HEADER_RENDER_AREA

#include <QtGui>

class RenderArea : public QLabel
 {
	 Q_OBJECT

	 public:
		 RenderArea(QWidget *parent,QString mAbscisse, QString mOrdonnee);

		 void addDataSet(QList<float> XDatas,QList<float> YDatas, Qt::GlobalColor Couleur=Qt::blue);
		 void setTitle(QString newTitle);
		 void clear();
		 void draw(QPaintDevice* Device, int Width = 3);

	 protected:
		 void paintEvent(QPaintEvent *event);

	 private:
		 QPixmap pixmap;
		 QList< QList< QPointF > > Datas;
		 QList<Qt::GlobalColor> Couleurs;
		 QList<QPointF> Points;
		 QString title;
		 QString Abscisse;
		 QString Ordonnee;
 };

 #endif
