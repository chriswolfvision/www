
#ifndef _WOLF_MOMENTS_H_
#define _WOLF_MOMENTS_H_

class Moments 
{
	public:
	double x, y, xx, yy, xy;
	double max, min;
	int peakX, peakY;
};

#endif

