/***********************************************************************
 * The global definitions necessary for all modules
 *
 * Author: Christian Wolf
 * Begin: 6.5.2005
 ***********************************************************************/
 
#include "CIL.h" 
 
/***********************************************************************
 * profiling stuff
 ***********************************************************************/
 
#ifdef ENABLE_PROFILING
clock_t LastProfilingClock=clock();
#endif
